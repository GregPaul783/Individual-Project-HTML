function play() {
    var audio = document.getElementById("audio");
    audio.play();
};

let toTop = () => window.scrollTo({top: 0, behavior: "smooth"});
